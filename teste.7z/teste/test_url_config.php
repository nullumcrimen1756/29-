<?php
/**
 * Test URL Configuration
 * File untuk testing semua URL helper functions
 */

require_once 'config.php';

// Test untuk konflik fungsi
if (function_exists('url')) {
    echo "<!-- WARNING: Function url() already exists before including url_helper.php -->";
}

require_once 'includes/url_helper.php';

// Verifikasi fungsi tersedia
$required_functions = ['url', 'asset', 'redirect', 'page_url', 'export_url', 'base_path', 'views_path'];
$missing_functions = [];
foreach ($required_functions as $func) {
    if (!function_exists($func)) {
        $missing_functions[] = $func;
    }
}

// Set header untuk HTML
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test URL Configuration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .test-section { margin-bottom: 30px; }
        .test-result { background-color: #f8f9fa; padding: 10px; border-radius: 5px; margin: 5px 0; }
        .success { border-left: 4px solid #28a745; }
        .info { border-left: 4px solid #17a2b8; }
        .warning { border-left: 4px solid #ffc107; }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1 class="mb-4">🧪 Test URL Configuration</h1>
        
        <!-- Function Availability Check -->
        <?php if (!empty($missing_functions)): ?>
        <div class="alert alert-danger">
            <h4>❌ Missing Functions</h4>
            <p>The following required functions are not available:</p>
            <ul>
                <?php foreach ($missing_functions as $func): ?>
                    <li><code><?= $func ?>()</code></li>
                <?php endforeach; ?>
            </ul>
            <p><strong>Solution:</strong> Make sure <code>includes/url_helper.php</code> is included properly.</p>
        </div>
        <?php else: ?>
        <div class="alert alert-success">
            <h4>✅ All Required Functions Available</h4>
            <p>All URL helper functions are loaded successfully.</p>
        </div>
        <?php endif; ?>

        <!-- Base Configuration -->
        <div class="test-section">
            <h3>📋 Base Configuration</h3>
            <div class="test-result success">
                <strong>BASE_URL:</strong> <?= defined('BASE_URL') ? BASE_URL : 'NOT DEFINED' ?>
            </div>
            <div class="test-result info">
                <strong>Current Script:</strong> <?= $_SERVER['SCRIPT_NAME'] ?>
            </div>
            <div class="test-result info">
                <strong>Document Root:</strong> <?= $_SERVER['DOCUMENT_ROOT'] ?>
            </div>
            <div class="test-result info">
                <strong>HTTP Host:</strong> <?= $_SERVER['HTTP_HOST'] ?>
            </div>
            <div class="test-result info">
                <strong>Functions Available:</strong>
                <?php
                $available_functions = array_filter($required_functions, 'function_exists');
                echo count($available_functions) . '/' . count($required_functions);
                ?>
            </div>
        </div>

        <!-- Basic URL Functions -->
        <div class="test-section">
            <h3>🔗 Basic URL Functions</h3>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Function</th>
                        <th>Input</th>
                        <th>Output</th>
                        <th>Test Link</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>url()</code></td>
                        <td>''</td>
                        <td><?= url() ?></td>
                        <td><a href="<?= url() ?>" target="_blank">Test</a></td>
                    </tr>
                    <tr>
                        <td><code>url()</code></td>
                        <td>'dashboard.php'</td>
                        <td><?= url('dashboard.php') ?></td>
                        <td><a href="<?= url('dashboard.php') ?>" target="_blank">Test</a></td>
                    </tr>
                    <tr>
                        <td><code>url()</code></td>
                        <td>'admin_kategori.php'</td>
                        <td><?= url('admin_kategori.php') ?></td>
                        <td><a href="<?= url('admin_kategori.php') ?>" target="_blank">Test</a></td>
                    </tr>
                    <tr>
                        <td><code>asset()</code></td>
                        <td>'css/style.css'</td>
                        <td><?= asset('css/style.css') ?></td>
                        <td><span class="text-muted">Asset</span></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Advanced URL Functions -->
        <div class="test-section">
            <h3>⚙️ Advanced URL Functions</h3>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Function</th>
                        <th>Parameters</th>
                        <th>Output</th>
                        <th>Test Link</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>page_url()</code></td>
                        <td>'index.php', ['action' => 'report']</td>
                        <td><?= page_url('index.php', ['action' => 'report']) ?></td>
                        <td><a href="<?= page_url('index.php', ['action' => 'report']) ?>" target="_blank">Test</a></td>
                    </tr>
                    <tr>
                        <td><code>export_url()</code></td>
                        <td>'sheet2_export.php', ['filter' => 1]</td>
                        <td><?= export_url('sheet2_export_structured.php', ['jurnal_filter' => 1, 'tahun_filter' => 2025]) ?></td>
                        <td><a href="<?= export_url('sheet2_export_structured.php', ['jurnal_filter' => 1, 'tahun_filter' => 2025]) ?>" target="_blank">Test</a></td>
                    </tr>
                    <tr>
                        <td><code>view_url()</code></td>
                        <td>'header', ['param' => 'test']</td>
                        <td><?= view_url('header', ['param' => 'test']) ?></td>
                        <td><span class="text-muted">View</span></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Navigation Helper Functions -->
        <div class="test-section">
            <h3>🧭 Navigation Helper Functions</h3>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Function</th>
                        <th>Input</th>
                        <th>Output</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>is_current_page()</code></td>
                        <td>'test_url_config.php'</td>
                        <td><?= is_current_page('test_url_config.php') ? 'true' : 'false' ?></td>
                        <td>Should be true</td>
                    </tr>
                    <tr>
                        <td><code>active_class()</code></td>
                        <td>'test_url_config.php'</td>
                        <td>'<?= active_class('test_url_config.php') ?>'</td>
                        <td>Should return 'active'</td>
                    </tr>
                    <tr>
                        <td><code>current_url()</code></td>
                        <td>-</td>
                        <td><?= current_url() ?></td>
                        <td>Current page URL</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- File Path Functions -->
        <div class="test-section">
            <h3>📁 File Path Functions</h3>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Function</th>
                        <th>Input</th>
                        <th>Output</th>
                        <th>Exists?</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>base_path()</code></td>
                        <td>''</td>
                        <td><?= base_path() ?></td>
                        <td><?= is_dir(base_path()) ? '✅' : '❌' ?></td>
                    </tr>
                    <tr>
                        <td><code>base_path()</code></td>
                        <td>'config.php'</td>
                        <td><?= base_path('config.php') ?></td>
                        <td><?= file_exists(base_path('config.php')) ? '✅' : '❌' ?></td>
                    </tr>
                    <tr>
                        <td><code>views_path()</code></td>
                        <td>''</td>
                        <td><?= views_path() ?></td>
                        <td><?= is_dir(views_path()) ? '✅' : '❌' ?></td>
                    </tr>
                    <tr>
                        <td><code>views_path()</code></td>
                        <td>'header.php'</td>
                        <td><?= views_path('header.php') ?></td>
                        <td><?= file_exists(views_path('header.php')) ? '✅' : '❌' ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Test Navigation -->
        <div class="test-section">
            <h3>🚀 Test Navigation</h3>
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Main Pages</h5>
                            <div class="d-grid gap-2">
                                <a href="<?= url('index.php') ?>" class="btn btn-primary btn-sm">Home</a>
                                <a href="<?= url('dashboard.php') ?>" class="btn btn-primary btn-sm">Dashboard</a>
                                <a href="<?= url('admin_kategori.php') ?>" class="btn btn-primary btn-sm">Admin Kategori</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Reports</h5>
                            <div class="d-grid gap-2">
                                <a href="<?= page_url('index.php', ['action' => 'report']) ?>" class="btn btn-success btn-sm">Sheet 1</a>
                                <a href="<?= page_url('index.php', ['action' => 'sheet2_report']) ?>" class="btn btn-success btn-sm">Sheet 2</a>
                                <a href="<?= page_url('index.php', ['action' => 'sheet3_report']) ?>" class="btn btn-success btn-sm">Sheet 3</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Debug Tools</h5>
                            <div class="d-grid gap-2">
                                <a href="<?= url('quick_debug.php') ?>" class="btn btn-warning btn-sm">Quick Debug</a>
                                <a href="<?= url('test_format_comparison.php') ?>" class="btn btn-info btn-sm">Format Test</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Summary -->
        <div class="test-section">
            <div class="alert alert-success">
                <h4>✅ URL Configuration Test Complete</h4>
                <p>Semua URL helper functions telah ditest. Jika semua link di atas berfungsi dengan baik, maka konfigurasi URL sudah benar.</p>
                <hr>
                <p class="mb-0"><strong>Base URL:</strong> <?= BASE_URL ?></p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
