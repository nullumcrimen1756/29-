<?php
// Test berbagai format angka untuk Excel

// Set header untuk download file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"Format_Test_" . date('Ymd_His') . ".xls\"");
header("Pragma: no-cache");
header("Expires: 0");

$test_values = [250000, 750000, 450000, 550000, 5000000];

function formatIndonesia($number) {
    return number_format($number, 0, ',', '.'); // 250.000
}

function formatInternational($number) {
    return number_format($number, 0, '.', ','); // 250,000
}

function formatNoSeparator($number) {
    return number_format($number, 0, '', ''); // 250000
}

function formatWithRp($number) {
    return 'Rp ' . number_format($number, 0, '.', ','); // Rp 250,000
}
?>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; }
        table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
        th, td { border: 1px solid #000; padding: 8px; text-align: left; }
        th { background-color: #f0f0f0; }
        .number-cell { mso-number-format: "#,##0"; text-align: right; }
        .text-cell { mso-number-format: "@"; text-align: right; }
        .currency-cell { mso-number-format: "#,##0"; text-align: right; }
    </style>
</head>
<body>
    <h2>TEST FORMAT ANGKA UNTUK EXCEL</h2>
    
    <h3>Tujuan: Mencari format yang membuat Excel menampilkan 250,000 bukan 250</h3>
    
    <table>
        <tr>
            <th>Nilai Asli</th>
            <th>Format Indonesia<br>(250.000)</th>
            <th>Format International<br>(250,000)</th>
            <th>No Separator<br>(250000)</th>
            <th>With Rp<br>(Rp 250,000)</th>
            <th>Excel Number Format<br>(mso-number-format)</th>
        </tr>
        <?php foreach ($test_values as $value): ?>
        <tr>
            <td><?= $value ?></td>
            <td class="text-cell"><?= formatIndonesia($value) ?></td>
            <td class="number-cell"><?= formatInternational($value) ?></td>
            <td class="currency-cell"><?= formatNoSeparator($value) ?></td>
            <td class="text-cell"><?= formatWithRp($value) ?></td>
            <td class="number-cell"><?= $value ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    
    <h3>Penjelasan Format:</h3>
    <ul>
        <li><strong>Format Indonesia:</strong> Menggunakan titik sebagai pemisah ribuan (250.000) - MUNGKIN MASALAH!</li>
        <li><strong>Format International:</strong> Menggunakan koma sebagai pemisah ribuan (250,000) - EXCEL FRIENDLY</li>
        <li><strong>No Separator:</strong> Tanpa pemisah (250000) - PALING AMAN</li>
        <li><strong>With Rp:</strong> Dengan prefix Rupiah (Rp 250,000)</li>
        <li><strong>Excel Number Format:</strong> Menggunakan CSS mso-number-format untuk memaksa Excel</li>
    </ul>
    
    <h3>Kesimpulan:</h3>
    <p>Jika Excel menampilkan 250 instead of 250,000, kemungkinan:</p>
    <ol>
        <li>Format Indonesia (250.000) dibaca sebagai desimal 250.0</li>
        <li>Solusi: Gunakan format International (250,000) atau No Separator (250000)</li>
        <li>Tambahkan CSS mso-number-format untuk memaksa Excel membaca sebagai angka</li>
    </ol>
    
    <p><strong>Generated at:</strong> <?= date('Y-m-d H:i:s') ?></p>
</body>
</html>
