<?php
function showForm() {
    global $conn, $daftar_jurnal;
    
    // Ambil data jurnal
    $jurnal = [];
    $sql = "SELECT * FROM jurnal ORDER BY nama_jurnal";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $jurnal[] = $row;
        }
    }
    
    // Ambil data kategori untuk jurnal pertama sebagai default
    $kategori = [];
    if (!empty($jurnal)) {
        $first_journal = $jurnal[0]['id_jurnal'];
        $sql = "SELECT * FROM kategori WHERE id_jurnal = ? ORDER BY kode_kategori";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $first_journal);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while($row = $result->fetch_assoc()) {
            $kategori[] = $row;
        }
    }
    
    include 'views/form.php';
}

function getKategoriByJurnal() {
    global $conn;
    
    $id_jurnal = isset($_GET['id_jurnal']) ? intval($_GET['id_jurnal']) : 0;
    
    $kategori = [];
    $sql = "SELECT * FROM kategori WHERE id_jurnal = ? ORDER BY kode_kategori";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_jurnal);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $kategori[] = $row;
    }
    
    header('Content-Type: application/json');
    echo json_encode($kategori);
    exit;
}

function getSubkategori() {
    global $conn;
    
    $id_kategori = isset($_GET['id_kategori']) ? intval($_GET['id_kategori']) : 0;
    
    // Debug log
    error_log("getSubkategori called with id_kategori: " . $id_kategori);
    
    $subkategori = [];
    $sql = "SELECT * FROM subkategori WHERE id_kategori = ? ORDER BY kode_subkategori";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_kategori);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $subkategori[] = $row;
    }
    
    // Debug log
    error_log("Subkategori found: " . count($subkategori));
    error_log("Data: " . json_encode($subkategori));
    
    header('Content-Type: application/json');
    echo json_encode($subkategori);
    exit;
}

function submitForm() {
    global $conn;
    
    // Validasi input
    $errors = [];
    
    if (empty($_POST['tanggal'])) {
        $errors[] = "Tanggal harus diisi";
    }
    
    if (empty($_POST['no_kwitansi'])) {
        $errors[] = "Nomor KW harus diisi";
    }
    
    if (empty($_POST['jumlah']) || !is_numeric($_POST['jumlah']) || $_POST['jumlah'] <= 0) {
        $errors[] = "Jumlah harus angka dan lebih dari 0";
    }
    
    if (empty($_POST['id_jurnal'])) {
        $errors[] = "Silakan pilih jurnal";
    }
    
    if (empty($_POST['id_kategori'])) {
        $errors[] = "Silakan pilih kategori";
    }
    
    if (empty($_POST['id_subkategori'])) {
        $errors[] = "Silakan pilih sub kategori";
    }
    
    if (count($errors) > 0) {
        $_SESSION['errors'] = $errors;
        header("Location: index.php");
        exit;
    }
    
    // Simpan data
    $tanggal = date('Y-m-d', strtotime($_POST['tanggal']));
    $no_kwitansi = $_POST['no_kwitansi'];
    $uraian = $_POST['uraian'];
    $jumlah = $_POST['jumlah'];
    $id_jurnal = $_POST['id_jurnal'];
    $id_subkategori = $_POST['id_subkategori'];
    $setoran = isset($_POST['setoran']) ? $_POST['setoran'] : 0;
    
    $sql = "INSERT INTO transaksi (tanggal, no_kwitansi, uraian, jumlah, id_jurnal, id_subkategori, setoran) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssdidd", $tanggal, $no_kwitansi, $uraian, $jumlah, $id_jurnal, $id_subkategori, $setoran);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Data transaksi berhasil disimpan!";
        
        // Proses laporan (Sheet 2 dan Sheet 3)
        generateReports();
    } else {
        $_SESSION['errors'] = ["Gagal menyimpan data: " . $conn->error];
    }
    
    header("Location: index.php");
    exit;
}

// Fungsi untuk menghasilkan laporan Sheet 2 (Terstruktur) dengan filter
function generateSheet2Report($jurnal_filter = null, $tahun_filter = null) {
    global $conn;
    
    $where_conditions = [];
    $params = [];
    $types = "";
    
    if ($jurnal_filter) {
        $where_conditions[] = "j.id_jurnal = ?";
        $params[] = $jurnal_filter;
        $types .= "i";
    }
    
    if ($tahun_filter) {
        $where_conditions[] = "YEAR(t.tanggal) = ?";
        $params[] = $tahun_filter;
        $types .= "i";
    }
    
    $where_clause = "";
    if (!empty($where_conditions)) {
        $where_clause = "WHERE " . implode(" AND ", $where_conditions);
    }
    
    $sql = "SELECT 
                DATE_FORMAT(t.tanggal, '%M %Y') as bulan,
                CONCAT(k.kode_kategori, ' - ', k.nama_kategori) as kategori,
                CONCAT(s.kode_subkategori, ' - ', s.nama_subkategori) as subkategori,
                t.tanggal,
                t.no_kwitansi,
                t.uraian,
                t.jumlah,
                j.nama_jurnal
            FROM transaksi t
            JOIN jurnal j ON t.id_jurnal = j.id_jurnal
            LEFT JOIN subkategori s ON t.id_subkategori = s.id_subkategori
            LEFT JOIN kategori k ON s.id_kategori = k.id_kategori
            $where_clause
            ORDER BY t.tanggal, j.nama_jurnal, k.kode_kategori, s.kode_subkategori";
    
    $stmt = $conn->prepare($sql);
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    $transactions = [];
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $transactions[] = $row;
        }
    }
    
    // Kelompokkan data berdasarkan jurnal, bulan, dan subkategori
    $structured_data = [];
    
    foreach ($transactions as $trx) {
        $jurnal = $trx['nama_jurnal'];
        $bulan = $trx['bulan'];
        $subkategori = $trx['subkategori'] ?: 'Uang Setoran';
        
        if (!isset($structured_data[$jurnal])) {
            $structured_data[$jurnal] = [];
        }
        
        if (!isset($structured_data[$jurnal][$bulan])) {
            $structured_data[$jurnal][$bulan] = [];
        }
        
        if (!isset($structured_data[$jurnal][$bulan][$subkategori])) {
            $structured_data[$jurnal][$bulan][$subkategori] = [
                'kategori' => $trx['kategori'],
                'transactions' => [],
                'total' => 0
            ];
        }
        
        $structured_data[$jurnal][$bulan][$subkategori]['transactions'][] = [
            'tanggal' => $trx['tanggal'],
            'no_kwitansi' => $trx['no_kwitansi'],
            'uraian' => $trx['uraian'],
            'jumlah' => $trx['jumlah']
        ];
        
        $structured_data[$jurnal][$bulan][$subkategori]['total'] += $trx['jumlah'];
    }
    
    // Simpan ke session untuk ditampilkan
    $_SESSION['sheet2_report'] = $structured_data;
}

// Fungsi untuk menghasilkan laporan Sheet 3 (Horizontal) dengan filter
function generateSheet3Report($jurnal_filter = null, $tahun_filter = null) {
    global $conn;
    
    $where_conditions = [];
    $params = [];
    $types = "";
    
    if ($jurnal_filter) {
        $where_conditions[] = "t.id_jurnal = ?";
        $params[] = $jurnal_filter;
        $types .= "i";
    }
    
    if ($tahun_filter) {
        $where_conditions[] = "YEAR(t.tanggal) = ?";
        $params[] = $tahun_filter;
        $types .= "i";
    }
    
    $where_clause = "";
    if (!empty($where_conditions)) {
        $where_clause = "WHERE " . implode(" AND ", $where_conditions);
    }
    
    $sql = "SELECT 
                t.*, 
                j.nama_jurnal, 
                j.id_jurnal,
                k.kode_kategori, 
                k.nama_kategori, 
                k.id_jurnal as kategori_jurnal_id,
                s.kode_subkategori, 
                s.nama_subkategori,
                DATE_FORMAT(t.tanggal, '%M %Y') as bulan_format
            FROM transaksi t
            JOIN jurnal j ON t.id_jurnal = j.id_jurnal
            LEFT JOIN subkategori s ON t.id_subkategori = s.id_subkategori
            LEFT JOIN kategori k ON s.id_kategori = k.id_kategori
            $where_clause
            ORDER BY t.tanggal";
    
    $stmt = $conn->prepare($sql);
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    $transactions = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $transactions[] = $row;
        }
    }

    // Anggaran (opsional; guard jika tabel belum ada)
    $anggaranDict = [];
    if ($conn->query("SHOW TABLES LIKE 'anggaran_pendapatan'")->num_rows) {
        // Cek struktur tabel untuk memastikan kolom 'type' ada
        $checkColumn = $conn->query("SHOW COLUMNS FROM anggaran_pendapatan LIKE 'type'");
        
        if ($checkColumn && $checkColumn->num_rows > 0) {
            // Kolom type ada, gunakan query dengan type
            $sqlAnggaran = "SELECT kode_subkategori, bulan, jumlah, type FROM anggaran_pendapatan";
            if ($resA = $conn->query($sqlAnggaran)) {
                while ($r = $resA->fetch_assoc()) {
                    $key = $r['kode_subkategori'] . '|' . $r['bulan'] . '|' . $r['type'];
                    $anggaranDict[$key] = (float)$r['jumlah'];
                }
            }
        } else {
            // Kolom type belum ada, gunakan query tanpa type (fallback)
            $sqlAnggaran = "SELECT kode_subkategori, bulan, jumlah FROM anggaran_pendapatan";
            if ($resA = $conn->query($sqlAnggaran)) {
                while ($r = $resA->fetch_assoc()) {
                    $key = $r['kode_subkategori'] . '|' . $r['bulan'] . '|subkategori';
                    $anggaranDict[$key] = (float)$r['jumlah'];
                }
            }
        }
    }

    // Uraian subkategori
    $uraianDict = [];
    if ($resU = $conn->query("SELECT kode_subkategori, nama_subkategori FROM subkategori")) {
        while ($r = $resU->fetch_assoc()) {
            $uraianDict[$r['kode_subkategori']] = $r['nama_subkategori'];
        }
    }

    $allBulan = [];
    $totalKas = [];
    $kategoriDict = [];
    $subKategoriDict = [];
    $totalPerKategoriBulan = [];
    $totalPerKelompok = [];
    $totalKeseluruhanPerBulan = [];
    $uangSetoranDict = [];
    $allCategories = [];
    $allSubCategories = [];

    // Kumpulkan kategori dan subkategori dari master
    foreach ($uraianDict as $kode => $nama) {
        $kategori = (strlen($kode) >= 6) ? substr($kode, 0, 6) : $kode;
        if (!in_array($kategori, $allCategories)) {
            $allCategories[] = $kategori;
            $allSubCategories[$kategori] = [];
        }
        if (!in_array($kode, $allSubCategories[$kategori])) {
            $allSubCategories[$kategori][] = $kode;
        }
    }

    foreach ($transactions as $trx) {
        $kas = (float)$trx['jumlah'];
        $bulan = $trx['bulan_format'];

        // Debug: Log nilai asli dari database
        error_log("DEBUG Sheet3: Original jumlah from DB: " . $trx['jumlah'] . " (type: " . gettype($trx['jumlah']) . "), converted to float: $kas");

        if ($kas == 0) continue;

        if (!in_array($bulan, $allBulan)) {
            $allBulan[] = $bulan;
            $totalKeseluruhanPerBulan[$bulan] = 0;
        }

        if (isUangSetoran($trx)) {
            $uangSetoranDict[$bulan] = ($uangSetoranDict[$bulan] ?? 0) + $kas;
        } else {
            $kodeSub = cleanCode($trx['kode_subkategori'] ?? '');
            if ($kodeSub === '') continue;

            $kategori = (strlen($kodeSub) >= 6) ? substr($kodeSub, 0, 6) : $kodeSub;

            if (!isset($kategoriDict[$kategori])) {
                $kategoriDict[$kategori] = true;
                $subKategoriDict[$kategori] = [];
            }
            if (!in_array($kodeSub, $subKategoriDict[$kategori])) {
                $subKategoriDict[$kategori][] = $kodeSub;
            }

            $uniqueKey = $kategori.'|'.$kodeSub.'|'.$bulan;
            $totalKas[$uniqueKey] = ($totalKas[$uniqueKey] ?? 0) + $kas;

            // Debug: Log nilai yang disimpan
            error_log("DEBUG Sheet3: Saving to totalKas[$uniqueKey] = " . $totalKas[$uniqueKey] . " (added $kas)");

            $kelompokKey = substr($kodeSub, 0, 3);
            $kelompokTotalKey = $kelompokKey.'|'.$bulan;
            $totalPerKelompok[$kelompokTotalKey] = ($totalPerKelompok[$kelompokTotalKey] ?? 0) + $kas;

            $totalKey = $kategori.'|'.$bulan;
            $totalPerKategoriBulan[$totalKey] = ($totalPerKategoriBulan[$totalKey] ?? 0) + $kas;
        }

        $totalKeseluruhanPerBulan[$bulan] += $kas;
    }

    usort($allBulan, fn($a,$b)=> strtotime($a)-strtotime($b));
    sort($allCategories);
    foreach ($allSubCategories as $k => $arr) sort($allSubCategories[$k]);

    $_SESSION['sheet3_report'] = [
        'bulan' => $allBulan,
        'uang_setoran' => $uangSetoranDict,
        'total_kas' => $totalKas,
        'kategori_dict' => $kategoriDict,
        'subkategori_dict' => $subKategoriDict,
        'total_per_kategori_bulan' => $totalPerKategoriBulan,
        'total_per_kelompok' => $totalPerKelompok,
        'total_keseluruhan_per_bulan' => $totalKeseluruhanPerBulan,
        'all_categories' => $allCategories,
        'all_sub_categories' => $allSubCategories,
        'uraian_dict' => $uraianDict,
        'anggaran_dict' => $anggaranDict
    ];
}

function isUangSetoran($trx) {
    if (empty($trx['kode_subkategori']) && (float)$trx['jumlah'] > 0) return true;
    if (!empty($trx['uraian']) && stripos($trx['uraian'], 'Uang Setoran') !== false) return true;
    return false;
}

function cleanCode($kode) {
    if (empty($kode)) return '';
    return preg_replace('/[^0-9.]/', '', $kode);
}

// Alias kompatibilitas bila ada pemanggilan lama
function generateHorizontalReport() {
    generateSheet3Report();
}

// Modifikasi fungsi generateReports untuk memanggil kedua laporan
function generateReports() {
    generateStructuredReport(); // jika masih dipakai
    generateSheet2Report();     // Sheet 2
    generateSheet3Report();     // Sheet 3
}

function showReport() {
    if (isset($_GET['type']) && $_GET['type'] == 'structured') {
        generateStructuredReport();
        include 'views/structured_report.php';
    } else {
        generateSheet3Report();
        include 'views/sheet3_report.php';
    }
}

/**
 * Validasi format kode kategori
 * @param string $kode
 * @return bool
 */
function validateKategoriCode($kode) {
    return preg_match('/^[0-9]{3}$/', $kode);
}

/**
 * Validasi format kode subkategori
 * @param string $kode
 * @return bool
 */
function validateSubkategoriCode($kode) {
    // Format: xxx.xx.xx atau xxx.xx.xxx
    return preg_match('/^[0-9]{3}\.[0-9]{2}(\.[0-9]{2,3})?$/', $kode);
}

/**
 * Generate kode subkategori otomatis berdasarkan kategori
 * @param string $kode_kategori
 * @param int $level
 * @return string
 */
function generateSubkategoriCode($kode_kategori, $level = 1) {
    if (!validateKategoriCode($kode_kategori)) {
        return false;
    }
    
    switch ($level) {
        case 1:
            return $kode_kategori . '.01';
        case 2:
            return $kode_kategori . '.01.001';
        default:
            return false;
    }
}

/**
 * Parse kode subkategori untuk mendapatkan informasi level
 * @param string $kode
 * @return array
 */
function parseSubkategoriCode($kode) {
    if (!validateSubkategoriCode($kode)) {
        return false;
    }
    
    $parts = explode('.', $kode);
    return [
        'kategori' => $parts[0],
        'sub_level_1' => $parts[1],
        'sub_level_2' => isset($parts[2]) ? $parts[2] : null,
        'total_levels' => count($parts)
    ];
}

// Fungsi untuk menghasilkan laporan Sheet 1 (Data Transaksi)
function generateSheet1Report($jurnal_filter = null, $tahun_filter = null) {
    global $conn;
    
    $where_conditions = [];
    $params = [];
    $types = "";
    
    if ($jurnal_filter) {
        $where_conditions[] = "t.id_jurnal = ?";
        $params[] = $jurnal_filter;
        $types .= "i";
    }
    
    if ($tahun_filter) {
        $where_conditions[] = "YEAR(t.tanggal) = ?";
        $params[] = $tahun_filter;
        $types .= "i";
    }
    
    $where_clause = "";
    if (!empty($where_conditions)) {
        $where_clause = "WHERE " . implode(" AND ", $where_conditions);
    }
    
    $sql = "SELECT 
                t.*,
                j.nama_jurnal,
                k.kode_kategori,
                k.nama_kategori,
                s.kode_subkategori,
                s.nama_subkategori
            FROM transaksi t
            JOIN jurnal j ON t.id_jurnal = j.id_jurnal
            LEFT JOIN subkategori s ON t.id_subkategori = s.id_subkategori
            LEFT JOIN kategori k ON s.id_kategori = k.id_kategori
            $where_clause
            ORDER BY t.tanggal DESC, t.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    $transactions = [];
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $transactions[] = $row;
        }
    }
    
    // Simpan ke session untuk ditampilkan
    $_SESSION['sheet1_report'] = $transactions;
}

/**
 * Simpan data anggaran pendapatan ke database
 */
function saveAnggaranPendapatan($data) {
    global $conn;
    
    $kode_subkategori = $data['kode_subkategori'] ?? '';
    $bulan = $data['bulan'] ?? '';
    $jumlah = $data['jumlah'] ?? 0;
    $type = $data['type'] ?? 'subkategori';
    
    // Validasi
    if (empty($bulan) || !is_numeric($jumlah)) {
        return ['success' => false, 'message' => 'Data tidak valid'];
    }
    
    // Cek apakah tabel anggaran_pendapatan ada
    $table_exists = $conn->query("SHOW TABLES LIKE 'anggaran_pendapatan'")->num_rows > 0;
    
    if (!$table_exists) {
        // Buat tabel jika belum ada (dengan kolom type)
        $create_table = "CREATE TABLE anggaran_pendapatan (
            id INT PRIMARY KEY AUTO_INCREMENT,
            kode_subkategori VARCHAR(50),
            bulan VARCHAR(20) NOT NULL,
            jumlah DECIMAL(15,2) NOT NULL DEFAULT 0.00,
            type ENUM('uang-setoran', 'kelompok', 'subkategori', 'keseluruhan') NOT NULL DEFAULT 'subkategori',
            UNIQUE KEY unique_anggaran (kode_subkategori, bulan, type)
        )";
        
        if (!$conn->query($create_table)) {
            return ['success' => false, 'message' => 'Gagal membuat tabel: ' . $conn->error];
        }
    }
    
    // Cek apakah kolom 'type' sudah ada di tabel
    $column_exists = $conn->query("SHOW COLUMNS FROM anggaran_pendapatan LIKE 'type'")->num_rows > 0;
    
    if ($column_exists) {
        // Query paling sederhana - tanpa ON DUPLICATE KEY
        // Cek dulu apakah data sudah ada
        $check_sql = "SELECT id FROM anggaran_pendapatan 
                     WHERE kode_subkategori = ? AND bulan = ? AND type = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("sss", $kode_subkategori, $bulan, $type);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            // Update data yang sudah ada - HANYA update jumlah
            $sql = "UPDATE anggaran_pendapatan SET jumlah = ? 
                    WHERE kode_subkategori = ? AND bulan = ? AND type = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("dsss", $jumlah, $kode_subkategori, $bulan, $type);
        } else {
            // Insert data baru
            $sql = "INSERT INTO anggaran_pendapatan (kode_subkategori, bulan, jumlah, type) 
                    VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssds", $kode_subkategori, $bulan, $jumlah, $type);
        }
    } else {
        // Fallback: query tanpa kolom type
        // Cek dulu apakah data sudah ada
        $check_sql = "SELECT id FROM anggaran_pendapatan 
                     WHERE kode_subkategori = ? AND bulan = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("ss", $kode_subkategori, $bulan);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            // Update data yang sudah ada
            $sql = "UPDATE anggaran_pendapatan SET jumlah = ? 
                    WHERE kode_subkategori = ? AND bulan = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("dss", $jumlah, $kode_subkategori, $bulan);
        } else {
            // Insert data baru
            $sql = "INSERT INTO anggaran_pendapatan (kode_subkategori, bulan, jumlah) 
                    VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssd", $kode_subkategori, $bulan, $jumlah);
        }
    }
    
    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'Anggaran berhasil disimpan'];
    } else {
        return ['success' => false, 'message' => 'Gagal menyimpan: ' . $conn->error];
    }
}

/**
 * API endpoint untuk menyimpan anggaran
 */
function handleSaveAnggaran() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);

        if (!$input) {
            echo json_encode(['success' => false, 'message' => 'Data tidak valid']);
            exit;
        }

        $result = saveAnggaranPendapatan($input);
        echo json_encode($result);
        exit;
    }
}

/**
 * Fungsi saveAnggaranPendapatan yang sangat sederhana (alternatif)
 * Gunakan ini jika fungsi utama masih error
 */
function saveAnggaranPendapatanSimple($data) {
    global $conn;
    
    $kode_subkategori = $data['kode_subkategori'] ?? '';
    $bulan = $data['bulan'] ?? '';
    $jumlah = $data['jumlah'] ?? 0;
    $type = $data['type'] ?? 'subkategori';
    
    try {
        // Coba update dulu
        $sql = "UPDATE anggaran_pendapatan SET jumlah = ? 
                WHERE kode_subkategori = ? AND bulan = ? AND type = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("dsss", $jumlah, $kode_subkategori, $bulan, $type);
        
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            return ['success' => true, 'message' => 'Anggaran berhasil diupdate'];
        }
        
        // Jika update tidak ada yang diubah, coba insert
        $sql = "INSERT INTO anggaran_pendapatan (kode_subkategori, bulan, jumlah, type) 
                VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssds", $kode_subkategori, $bulan, $jumlah, $type);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => 'Anggaran berhasil disimpan'];
        }
        
        return ['success' => false, 'message' => 'Gagal menyimpan'];
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
    }
}