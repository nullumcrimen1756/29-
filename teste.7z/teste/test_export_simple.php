<?php
session_start();
require_once 'config.php';

// Test sederhana untuk melihat nilai asli
if (!isset($_SESSION['sheet3_report'])) {
    require_once 'functions.php';
    generateSheet3Report();
}

$report = $_SESSION['sheet3_report'];

// Set header untuk download file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"Test_Debug_" . date('Ymd_His') . ".xls\"");
header("Pragma: no-cache");
header("Expires: 0");
?>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #000; padding: 8px; text-align: left; }
        th { background-color: #f0f0f0; }
        .number { text-align: right; }
    </style>
</head>
<body>
    <h2>DEBUG EXPORT - NILAI ASLI DARI SESSION</h2>
    
    <h3>1. Sample dari total_kas (RAW VALUES):</h3>
    <table>
        <tr><th>Key</th><th>Nilai Asli</th><th>Type</th><th>number_format</th><th>Dengan Rp</th></tr>
        <?php
        if (isset($report['total_kas'])) {
            $count = 0;
            foreach ($report['total_kas'] as $key => $value) {
                if ($count >= 10) break;
                echo "<tr>";
                echo "<td>" . htmlspecialchars($key) . "</td>";
                echo "<td class='number'>" . $value . "</td>";
                echo "<td>" . gettype($value) . "</td>";
                echo "<td class='number'>" . number_format($value, 0, ',', '.') . "</td>";
                echo "<td class='number'>Rp " . number_format($value, 0, ',', '.') . "</td>";
                echo "</tr>";
                $count++;
            }
        }
        ?>
    </table>
    
    <h3>2. Uang Setoran (jika ada):</h3>
    <table>
        <tr><th>Bulan</th><th>Nilai Asli</th><th>Type</th><th>Formatted</th></tr>
        <?php
        if (isset($report['uang_setoran'])) {
            foreach ($report['uang_setoran'] as $bulan => $value) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($bulan) . "</td>";
                echo "<td class='number'>" . $value . "</td>";
                echo "<td>" . gettype($value) . "</td>";
                echo "<td class='number'>Rp " . number_format($value, 0, ',', '.') . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>Tidak ada data uang setoran</td></tr>";
        }
        ?>
    </table>
    
    <h3>3. Test Direct Database Query:</h3>
    <table>
        <tr><th>Jumlah DB</th><th>Type</th><th>Uraian</th><th>Formatted</th></tr>
        <?php
        $sql = "SELECT jumlah, uraian FROM transaksi WHERE jumlah > 0 ORDER BY jumlah DESC LIMIT 5";
        $result = $conn->query($sql);
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td class='number'>" . $row['jumlah'] . "</td>";
                echo "<td>" . gettype($row['jumlah']) . "</td>";
                echo "<td>" . htmlspecialchars($row['uraian']) . "</td>";
                echo "<td class='number'>Rp " . number_format($row['jumlah'], 0, ',', '.') . "</td>";
                echo "</tr>";
            }
        }
        ?>
    </table>
    
    <h3>4. Info Session:</h3>
    <table>
        <tr><th>Key</th><th>Value</th></tr>
        <tr><td>Jumlah bulan</td><td><?= count($report['bulan'] ?? []) ?></td></tr>
        <tr><td>Jumlah total_kas</td><td><?= count($report['total_kas'] ?? []) ?></td></tr>
        <tr><td>Jumlah categories</td><td><?= count($report['all_categories'] ?? []) ?></td></tr>
        <tr><td>Jumlah uang_setoran</td><td><?= count($report['uang_setoran'] ?? []) ?></td></tr>
    </table>
    
    <p><strong>Generated at:</strong> <?= date('Y-m-d H:i:s') ?></p>
</body>
</html>
