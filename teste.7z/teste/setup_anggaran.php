<?php
// File setup otomatis untuk sistem anggaran
require_once 'config.php';

echo "<h2>Setup Sistem Anggaran Pendapatan</h2>";

    // 1. Buat tabel anggaran_pendapatan
    echo "<h3>1. Membuat Tabel anggaran_pendapatan</h3>";
    
            $create_table = "CREATE TABLE IF NOT EXISTS anggaran_pendapatan (
            id INT PRIMARY KEY AUTO_INCREMENT,
            kode_subkategori VARCHAR(50),
            bulan VARCHAR(20) NOT NULL,
            jumlah DECIMAL(15,2) NOT NULL DEFAULT 0.00,
            type ENUM('uang-setoran', 'kelompok', 'subkategori', 'keseluruhan') NOT NULL DEFAULT 'subkategori',
            UNIQUE KEY unique_anggaran (kode_subkategori, bulan, type)
        )";
    
    if ($conn->query($create_table)) {
        echo "✅ Tabel anggaran_pendapatan berhasil dibuat<br>";
    } else {
        echo "❌ Gagal membuat tabel: " . $conn->error . "<br>";
    }
    
    // 1.1. Perbaiki struktur tabel jika sudah ada tapi belum ada kolom type
    echo "<h3>1.1. Memperbaiki Struktur Tabel (jika diperlukan)</h3>";
    
    $table_exists = $conn->query("SHOW TABLES LIKE 'anggaran_pendapatan'")->num_rows > 0;
    if ($table_exists) {
        // Cek apakah kolom type sudah ada
        $type_column_exists = $conn->query("SHOW COLUMNS FROM anggaran_pendapatan LIKE 'type'")->num_rows > 0;
        
        if (!$type_column_exists) {
            // Tambahkan kolom type
            $add_column = "ALTER TABLE anggaran_pendapatan 
                          ADD COLUMN type ENUM('uang-setoran', 'kelompok', 'subkategori', 'keseluruhan') 
                          NOT NULL DEFAULT 'subkategori' AFTER jumlah";
            
            if ($conn->query($add_column)) {
                echo "✅ Kolom 'type' berhasil ditambahkan<br>";
            } else {
                echo "❌ Gagal menambahkan kolom 'type': " . $conn->error . "<br>";
            }
        } else {
            echo "✅ Kolom 'type' sudah tersedia<br>";
        }
        
        // Cek dan perbaiki unique key
        $unique_key_exists = $conn->query("SHOW INDEX FROM anggaran_pendapatan WHERE Key_name = 'unique_anggaran'")->num_rows > 0;
        
        if ($unique_key_exists) {
            // Hapus unique key lama jika ada
            $drop_key = "ALTER TABLE anggaran_pendapatan DROP INDEX unique_anggaran";
            $conn->query($drop_key);
            echo "✅ Unique key lama berhasil dihapus<br>";
        }
        
        // Tambahkan unique key baru
        $add_key = "ALTER TABLE anggaran_pendapatan 
                    ADD UNIQUE KEY unique_anggaran (kode_subkategori, bulan, type)";
        
        if ($conn->query($add_key)) {
            echo "✅ Unique key baru berhasil ditambahkan<br>";
        } else {
            echo "❌ Gagal menambahkan unique key: " . $conn->error . "<br>";
        }
    }

// 2. Cek apakah tabel sudah ada
$table_exists = $conn->query("SHOW TABLES LIKE 'anggaran_pendapatan'")->num_rows > 0;

if ($table_exists) {
    echo "<h3>2. Struktur Tabel</h3>";
    $result = $conn->query("DESCRIBE anggaran_pendapatan");
    if ($result) {
        echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
        echo "<tr style='background-color: #f0f0f0;'><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['Field']}</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['Type']}</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['Null']}</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['Key']}</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['Default']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    // 3. Insert data contoh
    echo "<h3>3. Insert Data Contoh</h3>";
    
    $sample_data = [
        ['kode_subkategori' => '100.01.01', 'bulan' => 'All', 'jumlah' => 1000000.00, 'type' => 'subkategori'],
        ['kode_subkategori' => '100.01.02', 'bulan' => 'All', 'jumlah' => 800000.00, 'type' => 'subkategori'],
        ['kode_subkategori' => '100', 'bulan' => 'All', 'jumlah' => 1800000.00, 'type' => 'kelompok'],
        ['kode_subkategori' => 'UANG_SETORAN', 'bulan' => 'All', 'jumlah' => 500000.00, 'type' => 'uang-setoran'],
        ['kode_subkategori' => 'TOTAL_KESELURUHAN', 'bulan' => 'All', 'jumlah' => 5000000.00, 'type' => 'keseluruhan']
    ];
    
    $inserted_count = 0;
    foreach ($sample_data as $data) {
        // Cek apakah data sudah ada
        $check_sql = "SELECT id FROM anggaran_pendapatan 
                     WHERE kode_subkategori = ? AND bulan = ? AND type = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("sss", $data['kode_subkategori'], $data['bulan'], $data['type']);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            // Update data yang sudah ada
            $sql = "UPDATE anggaran_pendapatan SET jumlah = ? 
                    WHERE kode_subkategori = ? AND bulan = ? AND type = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("dsss", $data['jumlah'], $data['kode_subkategori'], $data['bulan'], $data['type']);
            $action = "update";
        } else {
            // Insert data baru
            $sql = "INSERT INTO anggaran_pendapatan (kode_subkategori, bulan, jumlah, type) 
                    VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssds", $data['kode_subkategori'], $data['bulan'], $data['jumlah'], $data['type']);
            $action = "insert";
        }
        
        if ($stmt->execute()) {
            $inserted_count++;
            echo "✅ Data {$data['type']} - {$data['kode_subkategori']} berhasil di{$action}<br>";
        } else {
            echo "❌ Gagal {$action} data {$data['type']} - {$data['kode_subkategori']}: " . $stmt->error . "<br>";
        }
    }
    
    echo "<br>Total data berhasil diinsert: {$inserted_count} dari " . count($sample_data) . "<br>";
    
    // 4. Tampilkan data yang ada
    echo "<h3>4. Data Anggaran yang Tersedia</h3>";
    $result = $conn->query("SELECT * FROM anggaran_pendapatan ORDER BY type, kode_subkategori");
    if ($result && $result->num_rows > 0) {
        echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
        echo "<tr style='background-color: #f0f0f0;'><th>ID</th><th>Kode</th><th>Bulan</th><th>Jumlah</th><th>Type</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['id']}</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['kode_subkategori']}</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['bulan']}</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc; text-align: right;'>" . number_format($row['jumlah'], 2) . "</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['type']}</td>";

            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "Tidak ada data anggaran<br>";
    }
    
} else {
    echo "❌ Tabel anggaran_pendapatan tidak dapat dibuat<br>";
}

echo "<hr>";
echo "<h3>Setup Selesai!</h3>";
echo "<p><strong>Langkah selanjutnya:</strong></p>";
echo "<ol>";
echo "<li>Buka <a href='test_anggaran.php'>test_anggaran.php</a> untuk menguji sistem</li>";
echo "<li>Buka <a href='index.php?action=sheet3_report'>Sheet 3 Report</a> untuk mencoba fitur anggaran</li>";
echo "<li>Input nilai anggaran pada kolom 'Anggaran Pendapatan'</li>";
echo "<li>Data akan otomatis tersimpan ke database</li>";
echo "</ol>";

echo "<p><strong>Fitur yang tersedia:</strong></p>";
echo "<ul>";
echo "<li>✅ Input anggaran realtime untuk semua tipe (uang-setoran, kelompok, subkategori, keseluruhan)</li>";
echo "<li>✅ Penyimpanan otomatis ke database</li>";
echo "<li>✅ Reset anggaran dengan double click</li>";
echo "<li>✅ Notifikasi sukses/error</li>";
echo "<li>✅ Data tersimpan dan muncul kembali saat refresh</li>";
echo "</ul>";
?>
