# Panduan Setting Domain untuk Production

## 🌐 Cara Mengatur Base URL untuk Domain Website

### **Langkah 1: Edit config.php**

Buka file `config.php` dan ubah bagian Base URL Configuration:

```php
// Set base URL
// define('BASE_URL', getBaseUrl()); // Comment untuk production

// Manual base URL untuk production (uncomment dan edit sesuai domain)
define('BASE_URL', 'https://yourdomain.com/gereja');
```

### **Contoh Konfigurasi untuk Berbagai Skenario:**

#### **1. Domain Utama (Root Directory)**
```php
define('BASE_URL', 'https://gerejaku.com');
```

#### **2. Domain dengan Subdirectory**
```php
define('BASE_URL', 'https://gerejaku.com/keuangan');
```

#### **3. Subdomain**
```php
define('BASE_URL', 'https://keuangan.gerejaku.com');
```

#### **4. Domain dengan Port Khusus**
```php
define('BASE_URL', 'https://gerejaku.com:8080/sistem');
```

### **Langkah 2: Upload File ke Server**

1. **Upload semua file** ke directory yang sesuai di server
2. **Pastikan struktur folder** tetap sama seperti di localhost
3. **Set permission** yang tepat untuk folder dan file

### **Langkah 3: Konfigurasi Database**

Edit bagian database di `config.php`:

```php
// Konfigurasi Database untuk Production
define('DB_HOST', 'localhost'); // atau IP server database
define('DB_USER', 'username_database');
define('DB_PASS', 'password_database');
define('DB_NAME', 'nama_database');
```

### **Langkah 4: Testing**

1. **Akses website** melalui domain baru
2. **Test semua link** di navigation
3. **Test export functions** 
4. **Test form submission**
5. **Verifikasi semua asset** (CSS/JS) loading dengan benar

### **Langkah 5: Security untuk Production**

#### **A. Matikan Error Display**
Di `config.php`, pastikan error reporting dimatikan:
```php
// Error reporting untuk development (comment untuk production)
// error_reporting(E_ALL);
// ini_set('display_errors', 1);
```

#### **B. Ganti Password Default**
Di `login.php`, ganti password default:
```php
// Ganti password default untuk production
if ($username === 'admin' && $password === 'password_baru_yang_kuat') {
```

#### **C. Set HTTPS (Recommended)**
Pastikan website menggunakan SSL certificate dan akses melalui HTTPS.

## 🔧 Troubleshooting

### **Problem: Link Tidak Bekerja**
**Solusi:** Periksa apakah BASE_URL sudah benar dan sesuai dengan struktur folder di server.

### **Problem: CSS/JS Tidak Loading**
**Solusi:** Pastikan path ke asset benar dan file sudah terupload ke server.

### **Problem: Export Tidak Bekerja**
**Solusi:** Periksa permission folder dan pastikan PHP dapat menulis file temporary.

### **Problem: Database Connection Error**
**Solusi:** Periksa konfigurasi database dan pastikan user database memiliki permission yang tepat.

## 📝 Checklist Deployment

- [ ] Edit BASE_URL di config.php
- [ ] Upload semua file ke server
- [ ] Konfigurasi database connection
- [ ] Import database structure dan data
- [ ] Test semua functionality
- [ ] Ganti password default
- [ ] Matikan error reporting
- [ ] Setup SSL certificate (HTTPS)
- [ ] Test export functions
- [ ] Backup database dan files

## 🚀 Quick Setup Commands

### **Untuk cPanel/Shared Hosting:**
1. Upload file via File Manager atau FTP
2. Import database via phpMyAdmin
3. Edit config.php sesuai hosting

### **Untuk VPS/Dedicated Server:**
```bash
# Upload files
scp -r * user@server:/path/to/website/

# Set permissions
chmod 755 /path/to/website/
chmod 644 /path/to/website/*.php

# Import database
mysql -u username -p database_name < backup.sql
```

## � Rumus Perhitungan

### **Selisih Anggaran (Sheet 3)**
```
Selisih = Anggaran - Total Realisasi
```

**Interpretasi:**
- **Positif (Hijau)**: Anggaran lebih besar dari realisasi (surplus)
- **Negatif (Merah)**: Anggaran lebih kecil dari realisasi (defisit)
- **Nol (Biru)**: Anggaran sama dengan realisasi (seimbang)

## �📞 Support

Jika ada masalah saat deployment, periksa:
1. Error log server
2. PHP error log
3. Database connection
4. File permissions
5. BASE_URL configuration
