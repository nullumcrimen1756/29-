<?php
require_once 'config.php';

echo "<h2>Perbaikan Database Sistem Anggaran</h2>";

// Perbaiki struktur tabel anggaran_pendapatan
$queries = [
    "ALTER TABLE `anggaran_pendapatan` 
     ADD COLUMN IF NOT EXISTS `type` ENUM('uang-setoran', 'kelompok', 'subkategori', 'keseluruhan') NOT NULL DEFAULT 'subkategori' AFTER `jumlah`",
    
    "ALTER TABLE `anggaran_pendapatan` DROP INDEX IF EXISTS `unique_anggaran`",
    
    "ALTER TABLE `anggaran_pendapatan` 
     ADD UNIQUE KEY IF NOT EXISTS `unique_anggaran` (`kode_subkategori`, `bulan`, `type`)"
];

echo "<h3>1. Memperbaiki Struktur Tabel</h3>";

foreach ($queries as $index => $query) {
    echo "<p><strong>Query " . ($index + 1) . ":</strong></p>";
    echo "<code>" . htmlspecialchars($query) . "</code><br>";
    
    if ($conn->query($query)) {
        echo "✅ <strong>Berhasil:</strong> Query berhasil dieksekusi<br><br>";
    } else {
        echo "❌ <strong>Error:</strong> " . $conn->error . "<br><br>";
    }
}

// Cek struktur tabel setelah perbaikan
echo "<h3>2. Struktur Tabel Setelah Perbaikan</h3>";
$table_exists = $conn->query("SHOW TABLES LIKE 'anggaran_pendapatan'")->num_rows > 0;

if ($table_exists) {
    $result = $conn->query("DESCRIBE anggaran_pendapatan");
    if ($result) {
        echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
        echo "<tr style='background-color: #f0f0f0;'><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['Field']}</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['Type']}</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['Null']}</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['Key']}</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['Default']}</td>";
            echo "<td style='padding: 5px; border: 1px solid #ccc;'>{$row['Extra']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    // Cek apakah kolom type sudah ada
    $type_column_exists = $conn->query("SHOW COLUMNS FROM anggaran_pendapatan LIKE 'type'")->num_rows > 0;
    if ($type_column_exists) {
        echo "<p>✅ <strong>Kolom 'type' sudah tersedia</strong></p>";
    } else {
        echo "<p>❌ <strong>Kolom 'type' masih belum tersedia</strong></p>";
    }
    
    // Cek unique key
    $unique_key_exists = $conn->query("SHOW INDEX FROM anggaran_pendapatan WHERE Key_name = 'unique_anggaran'")->num_rows > 0;
    if ($unique_key_exists) {
        echo "<p>✅ <strong>Unique key 'unique_anggaran' sudah tersedia</strong></p>";
    } else {
        echo "<p>❌ <strong>Unique key 'unique_anggaran' masih belum tersedia</strong></p>";
    }
    
} else {
    echo "<p>❌ Tabel anggaran_pendapatan tidak ditemukan</p>";
}

echo "<hr>";
echo "<h3>Perbaikan Database Selesai!</h3>";
echo "<p><strong>Langkah selanjutnya:</strong></p>";
echo "<ol>";
echo "<li>Jika semua ✅ berhasil, sistem sudah siap digunakan</li>";
echo "<li>Jika ada ❌, jalankan query manual di phpMyAdmin</li>";
echo "<li>Buka <a href='index.php?action=sheet3_report'>Sheet 3 Report</a> untuk mencoba fitur anggaran</li>";
echo "</ol>";

// Tampilkan query manual jika diperlukan
echo "<h3>Query Manual untuk phpMyAdmin (jika diperlukan):</h3>";
echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px;'>";
echo "<code>";
echo "-- Tambahkan kolom type jika belum ada<br>";
echo "ALTER TABLE `anggaran_pendapatan` <br>";
echo "ADD COLUMN `type` ENUM('uang-setoran', 'kelompok', 'subkategori', 'keseluruhan') NOT NULL DEFAULT 'subkategori' AFTER `jumlah`;<br><br>";
echo "-- Hapus constraint unique lama jika ada<br>";
echo "ALTER TABLE `anggaran_pendapatan` DROP INDEX IF EXISTS `unique_anggaran`;<br><br>";
echo "-- Tambahkan constraint unique yang baru dengan kolom type<br>";
echo "ALTER TABLE `anggaran_pendapatan` <br>";
echo "ADD UNIQUE KEY `unique_anggaran` (`kode_subkategori`, `bulan`, `type`);";
echo "</code>";
echo "</div>";
?>
