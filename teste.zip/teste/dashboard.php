<?php
require_once 'config.php';
require_once 'functions.php';
require_once 'includes/url_helper.php';

session_start();

// Jika belum login, redirect ke halaman login
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// Set judul halaman
$page_title = "Dashboard - Sistem Keuangan Gereja";

// Ambil parameter filter
$selected_year = isset($_GET['tahun']) ? intval($_GET['tahun']) : date('Y');
$selected_jurnal = isset($_GET['jurnal']) ? intval($_GET['jurnal']) : null;

// Query untuk mendapatkan tahun-tahun yang tersedia (untuk placeholder/suggestion)
$query_years = "SELECT DISTINCT YEAR(tanggal) AS tahun FROM transaksi ORDER BY tahun DESC";
$years_result = $conn->query($query_years);

$available_years = [];
if ($years_result->num_rows > 0) {
    while($row = $years_result->fetch_assoc()) {
        $available_years[] = $row['tahun'];
    }
}

// Query untuk data summary tahunan berdasarkan jurnal
$sql_summary = "SELECT 
    j.id_jurnal,
    j.nama_jurnal,
    COUNT(t.id_transaksi) as total_transaksi,
    SUM(t.jumlah) as total_jumlah
FROM jurnal j
LEFT JOIN transaksi t ON j.id_jurnal = t.id_jurnal 
    AND YEAR(t.tanggal) = ?
    " . ($selected_jurnal ? " AND j.id_jurnal = $selected_jurnal " : "") . "
GROUP BY j.id_jurnal
ORDER BY j.id_jurnal";

$stmt = $conn->prepare($sql_summary);
$stmt->bind_param("i", $selected_year);
$stmt->execute();
$result_summary = $stmt->get_result();

$summary_data = [];
$total_keseluruhan = 0;
if ($result_summary->num_rows > 0) {
    while($row = $result_summary->fetch_assoc()) {
        $summary_data[] = $row;
        $total_keseluruhan += $row['total_jumlah'] ?? 0;
    }
}

// Query untuk data bulanan berdasarkan jurnal
$sql_monthly = "SELECT 
    MONTH(t.tanggal) as bulan,
    j.nama_jurnal,
    SUM(t.jumlah) as total_bulanan
FROM transaksi t
JOIN jurnal j ON t.id_jurnal = j.id_jurnal
WHERE YEAR(t.tanggal) = ?
" . ($selected_jurnal ? " AND t.id_jurnal = $selected_jurnal " : "") . "
GROUP BY MONTH(t.tanggal), j.nama_jurnal
ORDER BY bulan, j.id_jurnal";

$stmt = $conn->prepare($sql_monthly);
$stmt->bind_param("i", $selected_year);
$stmt->execute();
$monthly_result = $stmt->get_result();

// Organize monthly data by month and journal
$monthly_data = array_fill(1, 12, []);
$month_names = [
    1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 
    4 => 'April', 5 => 'Mei', 6 => 'Juni',
    7 => 'Juli', 8 => 'Agustus', 9 => 'September',
    10 => 'Oktober', 11 => 'November', 12 => 'Desember'
];

if ($monthly_result->num_rows > 0) {
    while($row = $monthly_result->fetch_assoc()) {
        $bulan = $row['bulan'];
        $jurnal = $row['nama_jurnal'];
        if (!isset($monthly_data[$bulan][$jurnal])) {
            $monthly_data[$bulan][$jurnal] = 0;
        }
        $monthly_data[$bulan][$jurnal] += $row['total_bulanan'];
    }
}

// Query untuk transaksi terakhir
$sql_last_trans = "SELECT t.*, j.nama_jurnal, k.nama_kategori, s.nama_subkategori
                   FROM transaksi t
                   JOIN jurnal j ON t.id_jurnal = j.id_jurnal
                   LEFT JOIN subkategori s ON t.id_subkategori = s.id_subkategori
                   LEFT JOIN kategori k ON s.id_kategori = k.id_kategori
                   WHERE YEAR(t.tanggal) = ?
                   " . ($selected_jurnal ? " AND t.id_jurnal = $selected_jurnal " : "") . "
                   ORDER BY t.tanggal DESC, t.created_at DESC
                   LIMIT 10";

$stmt = $conn->prepare($sql_last_trans);
$stmt->bind_param("i", $selected_year);
$stmt->execute();
$result_last_trans = $stmt->get_result();

$last_transactions = [];
if ($result_last_trans->num_rows > 0) {
    while($row = $result_last_trans->fetch_assoc()) {
        $last_transactions[] = $row;
    }
}

// Query untuk data terstruktur berdasarkan jurnal (jika jurnal dipilih)
$structured_data = [];
if ($selected_jurnal) {
    $sql_structured = "SELECT 
                        DATE_FORMAT(t.tanggal, '%M %Y') as bulan,
                        CONCAT(k.kode_kategori, ' - ', k.nama_kategori) as kategori,
                        CONCAT(s.kode_subkategori, ' - ', s.nama_subkategori) as subkategori,
                        t.tanggal,
                        t.no_kwitansi,
                        t.uraian,
                        t.jumlah
                      FROM transaksi t
                      JOIN jurnal j ON t.id_jurnal = j.id_jurnal
                      LEFT JOIN subkategori s ON t.id_subkategori = s.id_subkategori
                      LEFT JOIN kategori k ON s.id_kategori = k.id_kategori
                      WHERE t.id_jurnal = ? AND YEAR(t.tanggal) = ?
                      ORDER BY t.tanggal, k.kode_kategori, s.kode_subkategori";
    
    $stmt = $conn->prepare($sql_structured);
    $stmt->bind_param("ii", $selected_jurnal, $selected_year);
    $stmt->execute();
    $result_structured = $stmt->get_result();
    
    if ($result_structured->num_rows > 0) {
        while($row = $result_structured->fetch_assoc()) {
            $bulan = $row['bulan'];
            $subkategori = $row['subkategori'] ?: 'Lainnya';
            
            if (!isset($structured_data[$bulan])) {
                $structured_data[$bulan] = [];
            }
            
            if (!isset($structured_data[$bulan][$subkategori])) {
                $structured_data[$bulan][$subkategori] = [
                    'kategori' => $row['kategori'],
                    'transactions' => [],
                    'total' => 0
                ];
            }
            
            $structured_data[$bulan][$subkategori]['transactions'][] = [
                'tanggal' => $row['tanggal'],
                'no_kwitansi' => $row['no_kwitansi'],
                'uraian' => $row['uraian'],
                'jumlah' => $row['jumlah']
            ];
            
            $structured_data[$bulan][$subkategori]['total'] += $row['jumlah'];
        }
    }
}

// Include header
include 'views/header.php';
?>

<!-- Konten utama dashboard -->
<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">Dashboard Keuangan Gereja</h5>
    </div>
    <div class="card-body">
        <!-- Filter Tahun dan Jurnal -->
        <div class="row mb-4">
            <div class="col-md-12">
                <form method="get" action="dashboard.php" class="row g-3 align-items-center" id="filterForm">
                    <div class="col-auto">
                        <label for="yearInput" class="col-form-label fw-bold">Tahun:</label>
                    </div>
                    <div class="col-auto">
                        <input type="number" 
                               name="tahun" 
                               id="yearInput" 
                               class="form-control" 
                               value="<?= $selected_year ?>" 
                               min="2000" 
                               max="<?= date('Y') + 5 ?>"
                               list="yearSuggestions"
                               placeholder="Masukkan tahun"
                               style="max-width: 120px; text-align: center;">
                        <datalist id="yearSuggestions">
                            <?php foreach($available_years as $year): ?>
                            <option value="<?= $year ?>">
                            <?php endforeach; ?>
                        </datalist>
                    </div>
                    <div class="col-auto">
                        <label for="jurnal" class="col-form-label fw-bold">Jurnal:</label>
                    </div>
                    <div class="col-auto">
                        <select name="jurnal" id="jurnal" class="form-select" onchange="submitFilter()">
                            <option value="">Semua Jurnal</option>
                            <?php foreach ($daftar_jurnal as $id => $nama): ?>
                                <option value="<?= $id ?>" <?= ($selected_jurnal == $id) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($nama) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-auto">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-search me-1"></i>Cari
                        </button>
                        <?php if ($selected_jurnal || $selected_year != date('Y')): ?>
                            <a href="dashboard.php" class="btn btn-outline-secondary">
                                <i class="bi bi-arrow-clockwise me-1"></i>Reset
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <!-- Card Summary -->
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card summary-card">
                    <div class="card-header">
                        <h6 class="mb-0">Ringkasan Tahun <?= $selected_year ?></h6>
                    </div>
                    <div class="card-body">
                        <?php if(!empty($summary_data)): ?>
                        <div class="row">
                            <?php foreach ($summary_data as $summary): ?>
                                <div class="col-md-3 mb-3">
                                    <div class="card bg-primary text-white">
                                        <div class="card-body text-center">
                                            <h6 class="card-title"><?= htmlspecialchars($summary['nama_jurnal']) ?></h6>
                                            <p class="card-text mb-1"><?= $summary['total_transaksi'] ?> Transaksi</p>
                                            <p class="card-text fs-5 fw-bold">Rp <?= number_format($summary['total_jumlah'] ?? 0, 0, ',', '.') ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <h5>Total Keseluruhan Tahun <?= $selected_year ?></h5>
                                <p class="text-dark fs-3 fw-bold">Rp <?= number_format($total_keseluruhan, 0, ',', '.') ?></p>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="alert alert-warning">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            Tidak ada data untuk tahun <?= $selected_year ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Grafik dan Tabel -->
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0">Grafik Bulanan Tahun <?= $selected_year ?></h6>
                    </div>
                    <div class="card-body">
                        <canvas id="monthlyChart" height="300"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0">Transaksi Terbaru</h6>
                    </div>
                    <div class="card-body">
                        <?php if(!empty($last_transactions)): ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($last_transactions as $trans): ?>
                                <div class="list-group-item d-flex justify-content-between align-items-start">
                                    <div class="ms-2 me-auto">
                                        <div class="fw-bold"><?= htmlspecialchars($trans['nama_jurnal']) ?></div>
                                        <small class="text-muted">
                                            <?= htmlspecialchars($trans['nama_kategori'] ?? 'N/A') ?> - 
                                            <?= htmlspecialchars($trans['nama_subkategori'] ?? 'N/A') ?>
                                        </small>
                                    </div>
                                    <span class="badge bg-primary rounded-pill">
                                        Rp <?= number_format($trans['jumlah'], 0, ',', '.') ?>
                                    </span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <?php else: ?>
                        <p class="text-muted">
                            <i class="bi bi-info-circle me-2"></i>
                            Tidak ada transaksi
                        </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabel Detail Bulanan -->
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0">Detail Per Bulan Tahun <?= $selected_year ?></h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Bulan</th>
                                        <?php foreach ($daftar_jurnal as $id => $nama): ?>
                                            <th><?= htmlspecialchars($nama) ?></th>
                                        <?php endforeach; ?>
                                        <th class="text-end">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($month_names as $bulan_num => $bulan_nama): ?>
                                        <tr>
                                            <td><strong><?= $bulan_nama ?></strong></td>
                                            <?php 
                                            $total_bulan = 0;
                                            foreach ($daftar_jurnal as $id => $nama): 
                                                $jumlah = $monthly_data[$bulan_num][$nama] ?? 0;
                                                $total_bulan += $jumlah;
                                            ?>
                                                <td class="text-end">Rp <?= number_format($jumlah, 0, ',', '.') ?></td>
                                            <?php endforeach; ?>
                                            <td class="text-end fw-bold">Rp <?= number_format($total_bulan, 0, ',', '.') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tampilkan Data Terstruktur jika jurnal dipilih -->
        <?php if ($selected_jurnal && !empty($structured_data)): ?>
            <div class="row mt-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h6 class="mb-0">Data Terstruktur - <?= htmlspecialchars($daftar_jurnal[$selected_jurnal]) ?> (<?= $selected_year ?>)</h6>
                        </div>
                        <div class="card-body">
                            <?php foreach ($structured_data as $bulan => $subkategori_data): ?>
                                <h5 class="text-primary mb-3"><?= htmlspecialchars($bulan) ?></h5>
                                
                                <?php foreach ($subkategori_data as $subkategori => $data): ?>
                                    <div class="mb-4">
                                        <h6 class="text-secondary"><?= htmlspecialchars($subkategori) ?> (<?= htmlspecialchars($data['kategori']) ?>)</h6>
                                        
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-sm table-structured">
                                                <thead>
                                                    <tr>
                                                        <th>Tanggal</th>
                                                        <th>No. Kwitansi</th>
                                                        <th>Uraian</th>
                                                        <th class="text-end">Jumlah</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($data['transactions'] as $trans): ?>
                                                        <tr>
                                                            <td><?= date('d-m-Y', strtotime($trans['tanggal'])) ?></td>
                                                            <td><?= htmlspecialchars($trans['no_kwitansi']) ?></td>
                                                            <td><?= htmlspecialchars($trans['uraian']) ?></td>
                                                            <td class="text-end">Rp <?= number_format($trans['jumlah'], 0, ',', '.') ?></td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr class="table-info">
                                                        <th colspan="3" class="text-end">Total</th>
                                                        <th class="text-end fw-bold">Rp <?= number_format($data['total'], 0, ',', '.') ?></th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
// Script untuk chart dan input tahun
$custom_scripts = '
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Event listener untuk tombol Enter pada input tahun
document.getElementById("yearInput").addEventListener("keypress", function(e) {
    if (e.key === "Enter") {
        e.preventDefault(); // Mencegah submit default
        document.getElementById("filterForm").submit(); // Submit form
    }
});

// Event listener untuk validasi input tahun
document.getElementById("yearInput").addEventListener("blur", function() {
    const year = parseInt(this.value);
    const minYear = 2000;
    const maxYear = new Date().getFullYear() + 5;
    
    if (year < minYear || year > maxYear) {
        alert("Tahun harus antara " + minYear + " sampai " + maxYear);
        this.value = new Date().getFullYear();
        this.focus();
    }
});

document.addEventListener("DOMContentLoaded", function() {
    // Data untuk chart bulanan
    const monthlyData = {
        labels: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Ags", "Sep", "Okt", "Nov", "Des"],
        datasets: [';

// Generate datasets for each journal
foreach ($daftar_jurnal as $id => $nama) {
    $custom_scripts .= '
            {
                label: "' . htmlspecialchars($nama) . '",
                backgroundColor: getRandomColor(' . $id . '),
                borderColor: getRandomColor(' . $id . '),
                data: [';
    
    for ($bulan = 1; $bulan <= 12; $bulan++) {
        $jumlah = $monthly_data[$bulan][$nama] ?? 0;
        $custom_scripts .= $jumlah . ($bulan < 12 ? ',' : '');
    }
    
    $custom_scripts .= ']
            }' . ($id < max(array_keys($daftar_jurnal)) ? ',' : '');
}

$custom_scripts .= '
        ]
    };

    // Fungsi untuk generate warna yang konsisten
    function getRandomColor(seed) {
        const colors = [
            "rgba(13, 110, 253, 0.7)",   // Biru
            "rgba(25, 135, 84, 0.7)",    // Hijau
            "rgba(255, 193, 7, 0.7)",    // Kuning
            "rgba(220, 53, 69, 0.7)",    // Merah
            "rgba(102, 16, 242, 0.7)",   // Ungu
            "rgba(253, 126, 20, 0.7)",   // Orange
            "rgba(32, 201, 151, 0.7)",   // Teal
            "rgba(108, 117, 125, 0.7)"   // Gray
        ];
        return colors[seed % colors.length];
    }

    // Inisialisasi chart bulanan
    const monthlyCtx = document.getElementById("monthlyChart").getContext("2d");
    new Chart(monthlyCtx, {
        type: "bar",
        data: monthlyData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    stacked: true,
                },
                y: {
                    stacked: true,
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return "Rp " + value.toLocaleString("id-ID");
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || "";
                            if (label) {
                                label += ": ";
                            }
                            label += "Rp " + context.raw.toLocaleString("id-ID");
                            return label;
                        }
                    }
                }
            }
        }
    });
});
</script>';

// Include footer
include 'views/footer.php';
?>